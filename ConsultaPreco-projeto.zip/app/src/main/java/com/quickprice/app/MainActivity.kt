package com.quickprice.app

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.content.ActivityNotFoundException
import android.content.Intent
import android.widget.Toast
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebSettings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import java.util.concurrent.Executors
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.provider.MediaStore
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.request.target.ImageViewTarget
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.select.Elements

class MainActivity : AppCompatActivity() {
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private lateinit var credentialVault: CredentialVault
    private lateinit var txtNome: TextView
    private lateinit var txtCodigo: TextView
    private lateinit var txtPreco: TextView
    private lateinit var btnScan: Button
    private lateinit var imgProduto: ImageView
    private lateinit var imgBackdrop: ImageView
    @Volatile private var imagemToken = 0
    private lateinit var edtCodigo: EditText

    @Volatile private var client: CartazFacilClient? = null
    @Volatile private var authenticating = false
    private var currentUsername: String? = null
    private var soundPool: SoundPool? = null
    private var bipId = 0
    private lateinit var userAgent: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        credentialVault = CredentialVault(this)
        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
            .also { bipId = it.load(this, R.raw.bip, 1) }
        userAgent = WebSettings.getDefaultUserAgent(applicationContext)
        txtNome = findViewById(R.id.txtNome)
        txtCodigo = findViewById(R.id.txtCodigo)
        txtPreco = findViewById(R.id.txtPreco)
        btnScan = findViewById(R.id.btnScan)
        imgProduto = findViewById(R.id.imgProduto)
        imgBackdrop = findViewById(R.id.imgBackdrop)
        findViewById<View>(R.id.btnSuporte).setOnClickListener { abrirWhatsAppSuporte() }
        edtCodigo = findViewById(R.id.edtCodigo)
        edtCodigo.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                isEnter
            ) {
                buscarCodigoDigitado()
                true
            } else {
                false
            }
        }
        btnScan.isEnabled = false
        btnScan.setOnClickListener {
            if (client == null) reconectarOuPedirLogin()
            else abrirScanner()
        }

        val saved = credenciais()
        if (saved == null) {
            showLoginDialog()
        } else {
            currentUsername = saved.username
            authenticate(saved.username, saved.password, remember = false)
        }
    }

    private fun decodificar(s: String): String {
        if (s.isEmpty()) return ""
        val key = "qp-7Kx!".toByteArray(Charsets.UTF_8)
        val b = Base64.decode(s, Base64.DEFAULT)
        return String(ByteArray(b.size) { (b[it].toInt() xor key[it % key.size].toInt()).toByte() }, Charsets.UTF_8)
    }

    /** Login que já vai dentro do app (vem dos Secrets do GitHub na hora de compilar). */
    private fun credenciaisEmbutidas(): SavedCredentials? {
        val u = decodificar(BuildConfig.CF_USER)
        val p = decodificar(BuildConfig.CF_PASS)
        return if (u.isNotEmpty() && p.isNotEmpty()) SavedCredentials(u, p) else null
    }

    /** Usa o login embutido; se não houver, usa a senha salva no aparelho. */
    private fun credenciais(): SavedCredentials? = credenciaisEmbutidas() ?: credentialVault.load()

    private fun showLoginDialog(prefillUsername: String? = null, message: String? = null) {
        if (isFinishing) return

        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(4))
        }
        val username = EditText(this).apply {
            hint = "Usuário"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            prefillUsername?.let { setText(it) }
        }
        val password = EditText(this).apply {
            hint = "Senha"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        fields.addView(username, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        fields.addView(password, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Acesso ao sistema")
            .setMessage(message ?: "O acesso fica salvo criptografado neste aparelho.")
            .setView(fields)
            .setNegativeButton("Cancelar") { _, _ ->
                btnScan.isEnabled = true
                txtNome.text = "Conecte-se para consultar preços."
            }
            .setPositiveButton("Conectar", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val userValue = username.text.toString().trim()
                val passwordValue = password.text.toString()
                if (userValue.isEmpty() || passwordValue.isEmpty()) {
                    if (userValue.isEmpty()) username.error = "Informe o usuário"
                    if (passwordValue.isEmpty()) password.error = "Informe a senha"
                    return@setOnClickListener
                }
                password.text?.clear()
                dialog.dismiss()
                authenticate(userValue, passwordValue, remember = true)
            }
        }
        dialog.show()
    }

    private fun authenticate(username: String, password: String, remember: Boolean) {
        if (authenticating) return
        authenticating = true
        currentUsername = username
        btnScan.isEnabled = false
        txtNome.text = "Conectando..."

        networkExecutor.execute {
            val attempt = CartazFacilClient(userAgent)
            try {
                attempt.login(username, password)
                var credentialsSaved = true
                if (remember) {
                    credentialsSaved = try {
                        credentialVault.save(username, password)
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                client = attempt
                runOnUiThread {
                    authenticating = false
                    btnScan.isEnabled = true
                    txtNome.text = if (credentialsSaved) {
                        "Conectado. Escaneie um produto."
                    } else {
                        "Conectado. A senha não pôde ser salva neste aparelho."
                    }
                }
            } catch (error: Exception) {
                client = null
                // Só apaga a senha salva se o site recusou o usuário/senha.
                // Erro de internet ou site fora do ar NÃO apaga mais a senha.
                val recusada = error is CartazBadCredentialsException
                if (recusada) credentialVault.clear()
                val safeMessage = if (error is CartazFacilException) error.message else "Sem conexão. Verifique a internet e tente de novo."
                runOnUiThread {
                    authenticating = false
                    btnScan.isEnabled = true
                    if (credenciaisEmbutidas() != null) {
                        txtNome.text = if (recusada) "Acesso indisponível. Fale com o suporte."
                        else "Sem conexão. Toque em ESCANEAR para tentar de novo."
                    } else if (remember || recusada) {
                        txtNome.text = "Falha ao conectar"
                        showLoginDialog(username, safeMessage)
                    } else {
                        txtNome.text = "Sem conexão. Toque em ESCANEAR para tentar de novo."
                    }
                }
            }
        }
    }

    /** Usa a senha salva (sem pedir de novo); só abre o login se não houver senha salva. */
    private fun reconectarOuPedirLogin() {
        val saved = credenciais()
        if (saved == null) {
            showLoginDialog(currentUsername)
        } else {
            currentUsername = saved.username
            authenticate(saved.username, saved.password, remember = false)
        }
    }

    /** Consulta; se a sessão expirou, entra de novo com a senha salva e repete a consulta. */
    private fun consultarComRenovacao(barcode: String): PriceLookupResult {
        val atual = client
        if (atual != null) {
            try {
                return atual.lookupPrice(barcode)
            } catch (e: CartazLoginException) {
                // sessão expirou: tenta renovar abaixo
            }
        }
        val saved = credenciais()
            ?: throw CartazLoginException("Faça o login.")
        val novo = CartazFacilClient(userAgent)
        novo.login(saved.username, saved.password)
        client = novo
        return novo.lookupPrice(barcode)
    }

    private fun abrirWhatsAppSuporte() {
        val mensagem = "Olá Felipe! Preciso de suporte no app Consulta de Preço."
        val uri = Uri.parse("https://wa.me/$SUPORTE_WHATSAPP?text=${Uri.encode(mensagem)}")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir o WhatsApp", Toast.LENGTH_SHORT).show()
        }
    }

    // Mesmo caminho do scanner: normaliza o texto e chama consultarPreco().
    private fun buscarCodigoDigitado() {
        val codigo = edtCodigo.text.toString().filter { !it.isWhitespace() }
        if (codigo.isEmpty()) {
            edtCodigo.error = "Digite o código de barras"
            return
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(edtCodigo.windowToken, 0)
        consultarPreco(codigo)
    }

    /** Bip de confirmação ao ler um código (arquivo res/raw/bip.wav, volume de mídia). */
    private fun tocarBip() {
        try {
            soundPool?.play(bipId, 1f, 1f, 1, 0, 1f)
        } catch (e: Exception) {
            Log.e("MainActivity", "Erro ao tocar bip: ${e.message}")
        }
    }

    private fun abrirScanner() {
        val intent = Intent(this, ScannerActivity::class.java)
        startActivityForResult(intent, REQUEST_SCAN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SCAN && resultCode == RESULT_OK) {
            val barcode = data?.getStringExtra("codigo")?.trim().orEmpty()
            if (barcode.isNotEmpty()) {
                tocarBip()
                consultarPreco(barcode)
            }
        }
    }

    private fun consultarPreco(barcode: String) {
        if (client == null && credenciais() == null) {
            showLoginDialog(currentUsername)
            return
        }

        btnScan.isEnabled = false
        txtCodigo.text = barcode
        txtNome.text = "Consultando preço..."
        txtPreco.text = "R$ --"
        imagemToken++
        mostrarImagem(null)

        networkExecutor.execute {
            try {
                val result = consultarComRenovacao(barcode)
                runOnUiThread {
                    txtNome.text = result.product.description
                    txtCodigo.text = "${result.product.code} · $barcode"
                    txtPreco.text = "R$ ${result.price.display}"

                    // Buscar foto do produto na base de dados Beep/Go-UPC
                    buscarImagemProduto(barcode)

                    btnScan.isEnabled = true
                    edtCodigo.text?.clear()
                }
            } catch (error: CartazLoginException) {
                client = null
                if (error is CartazBadCredentialsException) credentialVault.clear()
                runOnUiThread {
                    btnScan.isEnabled = true
                    if (credenciaisEmbutidas() != null) {
                        txtNome.text = "Acesso indisponível. Fale com o suporte."
                    } else {
                        txtNome.text = "É preciso entrar de novo"
                        showLoginDialog(currentUsername, error.message)
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    txtNome.text = if (error is CartazFacilException) (error.message ?: "Não foi possível consultar este produto.") else "Sem conexão. Verifique a internet e tente de novo."
                    txtPreco.text = "R$ --"
                    btnScan.isEnabled = true
                }
            }
        }
    }

    private fun buscarImagemProduto(codigoBarras: String) {
        val token = ++imagemToken
        val url = "https://www.beepscan.com/barcode/$codigoBarras"

        networkExecutor.execute {
            val imageUrl: String? = try {
                val document = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .timeout(8000)
                    .get()
                // 1) imagem oficial da pagina (og:image); 2) primeira <img> que nao seja logo/svg
                document.selectFirst("meta[property=og:image]")?.attr("abs:content")
                    ?.takeIf { it.startsWith("http") }
                    ?: document.select("img[src]")
                        .map { it.attr("abs:src") }
                        .firstOrNull {
                            it.startsWith("http") &&
                                !it.endsWith(".svg", ignoreCase = true) &&
                                !it.contains("logo", ignoreCase = true)
                        }
            } catch (e: Exception) {
                Log.e("MainActivity", "Erro ao buscar imagem: ${e.message}")
                null
            }
            runOnUiThread {
                if (token == imagemToken) mostrarImagem(imageUrl)
            }
        }
    }

    /** Foto com degradê estilo Netflix + o mesmo fundo desfocado atrás. */
    private fun mostrarImagem(model: String?) {
        if (isFinishing || isDestroyed) return
        if (model.isNullOrEmpty()) {
            Glide.with(this).clear(imgBackdrop)
            imgBackdrop.setImageDrawable(null)
            imgProduto.setImageResource(R.drawable.ic_placeholder_box)
            return
        }
        Glide.with(this)
            .load(model)
            .error(R.drawable.ic_placeholder_box)
            .transform(NetflixEdgeTransformation.getTransformation())
            .into(imgProduto)

        // Imagem minúscula esticada = efeito de blur barato e sem biblioteca extra
        Glide.with(this)
            .load(model)
            .override(24, 48)
            .transform(CenterCrop())
            .into(imgBackdrop)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        soundPool?.release()
        soundPool = null
        networkExecutor.shutdownNow()
        super.onDestroy()
    }

    private companion object {
        const val REQUEST_SCAN = 100
        // WhatsApp do suporte: DDI 55 + DDD 21 + número
        const val SUPORTE_WHATSAPP = "5521990706088"
    }
}
